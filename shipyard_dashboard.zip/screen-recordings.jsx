// Screen: 레코딩 관리 (RTDE)
// New/active recording controls + library of past recordings (file/DB).

function ScreenRecordings({ library, session, startRecording, stopRecording, openInAnalysis, activeRecId }) {
  const [source, setSource] = React.useState('all'); // all | file | db
  const [q, setQ] = React.useState('');
  const [showNewDialog, setShowNewDialog] = React.useState(false);

  const filtered = library.filter(r => {
    if (source !== 'all' && r.source !== source) return false;
    if (q) {
      const s = q.toLowerCase();
      if (!r.name.toLowerCase().includes(s) &&
          !r.block.toLowerCase().includes(s) &&
          !r.operator.includes(q)) return false;
    }
    return true;
  });

  return (
    <div style={{
      flex: 1, display: 'flex', flexDirection: 'column',
      minHeight: 0, background: TOKENS.bg,
      overflowY: 'auto',
    }}>
      {/* If recording: massive recording panel */}
      {session ? (
        <ActiveRecordingPanel session={session} stopRecording={stopRecording} />
      ) : (
        <NewRecordingPanel onStart={() => setShowNewDialog(true)} />
      )}

      {/* Library */}
      <div style={{
        padding: '20px 24px 8px',
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        <h2 style={{
          margin: 0, fontSize: 13, color: TOKENS.text,
          fontFamily: 'JetBrains Mono, monospace', letterSpacing: 1, fontWeight: 500,
        }}>
          레코딩 라이브러리
        </h2>
        <span style={{
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 10, color: TOKENS.dim,
        }}>· {library.length} 항목 · 62.3GB / 180GB 사용중</span>
        <span style={{ flex: 1 }} />
        <div style={{ display: 'inline-flex', gap: 1, background: TOKENS.border, padding: 1, borderRadius: 2 }}>
          {[
            ['all', '전체', library.length],
            ['file', '파일 시스템', library.filter(r => r.source==='file').length],
            ['db', '데이터베이스', library.filter(r => r.source==='db').length],
          ].map(([k, label, count]) => (
            <button key={k} onClick={() => setSource(k)}
              style={{
                padding: '5px 12px',
                background: source === k ? TOKENS.bg : TOKENS.panel2,
                color: source === k ? TOKENS.accent : TOKENS.dim,
                border: 'none',
                fontFamily: 'JetBrains Mono, monospace',
                fontSize: 10, letterSpacing: 0.5,
                cursor: 'pointer',
                borderRadius: 1,
              }}>
              {label} <span style={{ color: TOKENS.muted, marginLeft: 4 }}>{count}</span>
            </button>
          ))}
        </div>
        <input value={q} onChange={(e) => setQ(e.target.value)}
          placeholder="블록 / 작업자 / 파일명"
          style={{
            background: TOKENS.panel, border: `1px solid ${TOKENS.border}`,
            color: TOKENS.text, fontFamily: 'JetBrains Mono, monospace',
            fontSize: 11, padding: '5px 10px', borderRadius: 2, outline: 'none',
            width: 220,
          }} />
      </div>

      <div style={{ padding: '0 24px 24px' }}>
        <RecordingTable
          rows={filtered}
          activeRecId={activeRecId}
          onOpen={openInAnalysis} />
      </div>

      {showNewDialog && (
        <NewRecordingDialog
          onClose={() => setShowNewDialog(false)}
          onConfirm={(meta) => {
            startRecording(meta);
            setShowNewDialog(false);
          }} />
      )}
    </div>
  );
}

function NewRecordingPanel({ onStart }) {
  return (
    <div style={{
      margin: 24,
      padding: 24,
      background: TOKENS.panel,
      border: `1px solid ${TOKENS.border}`,
      display: 'grid',
      gridTemplateColumns: 'auto 1fr auto',
      gap: 24,
      alignItems: 'center',
    }}>
      <div style={{
        width: 80, height: 80,
        border: `2px solid ${TOKENS.accent}`,
        borderRadius: '50%',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: TOKENS.accent,
      }}>
        <svg width="42" height="42" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="12" cy="12" r="6" fill="currentColor" />
        </svg>
      </div>
      <div>
        <div style={{
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 10, color: TOKENS.dim, letterSpacing: 1.2,
        }}>NEW RECORDING</div>
        <div style={{ fontSize: 20, color: TOKENS.text, fontWeight: 500, marginTop: 4 }}>
          RTDE 레코딩 시작
        </div>
        <div style={{
          fontSize: 12, color: TOKENS.dim, marginTop: 6, lineHeight: 1.5,
        }}>
          UR RTDE의 General Purpose 영역과 Modbus 값을 동일 timestamp 축으로
          병합 저장합니다. 사후 분석 워크스페이스에서 즉시 로드 가능.
        </div>
        <div style={{
          display: 'flex', gap: 14, marginTop: 12,
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 10, color: TOKENS.dim, letterSpacing: 0.5,
        }}>
          <span>샘플레이트 <span style={{ color: TOKENS.text }}>125Hz</span></span>
          <span>·</span>
          <span>예상 크기 <span style={{ color: TOKENS.text }}>~6KB/s</span></span>
          <span>·</span>
          <span>최대 길이 <span style={{ color: TOKENS.text }}>제한 없음</span></span>
        </div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        <button onClick={onStart}
          style={{
            padding: '12px 28px',
            background: TOKENS.accent,
            color: '#0a0f1c',
            border: 'none',
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 12, letterSpacing: 1, fontWeight: 600,
            cursor: 'pointer',
            borderRadius: 2,
          }}>
          ● 새 레코딩 시작
        </button>
        <button
          style={{
            padding: '8px 28px',
            background: 'transparent',
            color: TOKENS.dim,
            border: `1px solid ${TOKENS.border}`,
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 10, letterSpacing: 0.8,
            cursor: 'pointer',
            borderRadius: 2,
          }}>
          파일 가져오기 (.csv)
        </button>
      </div>
    </div>
  );
}

function ActiveRecordingPanel({ session, stopRecording }) {
  const elapsed = Math.floor((Date.now() - session.startedAt) / 1000);
  const samples = elapsed * 125;
  const sizeMB = (samples * 56 / 1024 / 1024).toFixed(2);

  // Simulated live values streaming
  const M = window.MODBUS;
  const [state, setState] = React.useState(M.state);
  React.useEffect(() => M.subscribe((s) => setState({ ...s })), []);

  return (
    <div style={{
      margin: 24,
      padding: 0,
      background: TOKENS.red + '08',
      border: `1px solid ${TOKENS.red}66`,
      borderLeft: `4px solid ${TOKENS.red}`,
      display: 'flex', flexDirection: 'column',
    }}>
      {/* Header row */}
      <div style={{
        padding: '20px 28px',
        display: 'grid',
        gridTemplateColumns: 'auto 1fr auto auto auto',
        gap: 32,
        alignItems: 'center',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <span style={{
            width: 16, height: 16, borderRadius: '50%',
            background: TOKENS.red,
            boxShadow: `0 0 16px ${TOKENS.red}`,
            animation: 'pulse 1s ease-in-out infinite',
          }} />
          <div>
            <div style={{
              fontFamily: 'JetBrains Mono, monospace',
              fontSize: 10, color: TOKENS.red, letterSpacing: 1.4, fontWeight: 600,
            }}>RECORDING</div>
            <div style={{
              fontFamily: 'JetBrains Mono, monospace',
              fontSize: 11, color: TOKENS.text, marginTop: 2,
            }}>{session.meta?.name}</div>
          </div>
        </div>
        <div>
          <div style={{
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 10, color: TOKENS.dim, letterSpacing: 1.2,
          }}>ELAPSED</div>
          <div style={{
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 36, fontWeight: 500, color: TOKENS.text,
            letterSpacing: -1, lineHeight: 1.1, marginTop: 2,
          }}>{fmtT(elapsed)}</div>
        </div>
        <RecStat label="샘플" value={samples.toLocaleString()} />
        <RecStat label="크기" value={`${sizeMB} MB`} />
        <button onClick={stopRecording}
          style={{
            padding: '14px 28px',
            background: TOKENS.red,
            color: '#fff',
            border: 'none',
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 13, letterSpacing: 1, fontWeight: 600,
            cursor: 'pointer',
            borderRadius: 2,
          }}>
          ■ 정지 및 저장
        </button>
      </div>

      {/* Live values being captured */}
      <div style={{
        padding: '0 28px 20px',
        display: 'grid',
        gridTemplateColumns: 'repeat(6, 1fr)',
        gap: 1,
        background: TOKENS.border,
      }}>
        {[131, 132, 212, 213, 214, 158].map(addr => {
          const r = M.byAddr[addr];
          const hist = M.getHist(addr);
          return (
            <div key={addr} style={{
              background: TOKENS.panel,
              padding: '10px 12px',
              display: 'flex', flexDirection: 'column', gap: 4,
            }}>
              <div style={{
                fontFamily: 'JetBrains Mono, monospace',
                fontSize: 9, color: TOKENS.muted, letterSpacing: 0.6,
              }}>{r.a} · {r.name}</div>
              <div style={{
                fontFamily: 'JetBrains Mono, monospace',
                fontSize: 18, color: TOKENS.text, fontWeight: 500,
              }}>
                {fmt(state[addr], 1)}
                <span style={{ fontSize: 9, color: TOKENS.dim, marginLeft: 4 }}>{r.unit}</span>
              </div>
              <Sparkline values={hist} w={140} h={20} color={TOKENS.red} fill />
            </div>
          );
        })}
      </div>

      {/* Capture path */}
      <div style={{
        padding: '12px 28px',
        background: TOKENS.bg + '88',
        borderTop: `1px solid ${TOKENS.border}`,
        display: 'flex', alignItems: 'center', gap: 18,
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 10, color: TOKENS.dim,
      }}>
        <span style={{ color: TOKENS.text }}>저장 위치</span>
        <span>/var/shipyard/recordings/{session.meta?.name}</span>
        <span style={{ color: TOKENS.border }}>·</span>
        <span>RTDE 40컬럼 + Modbus 활성 레지스터 자동 병합</span>
        <span style={{ flex: 1 }} />
        <span style={{ color: TOKENS.green }}>● Modbus OK</span>
        <span style={{ color: TOKENS.green }}>● RTDE OK</span>
      </div>
    </div>
  );
}

function RecStat({ label, value }) {
  return (
    <div>
      <div style={{
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 10, color: TOKENS.dim, letterSpacing: 1.2,
      }}>{label}</div>
      <div style={{
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 20, color: TOKENS.text, fontWeight: 500, marginTop: 2,
      }}>{value}</div>
    </div>
  );
}

function NewRecordingDialog({ onClose, onConfirm }) {
  const [block, setBlock] = React.useState('BH-12');
  const [cell, setCell] = React.useState('VL2');
  const [path, setPath] = React.useState('2/3');
  const [operator, setOperator] = React.useState('김재성');
  const [note, setNote] = React.useState('');

  const now = new Date();
  const f = (n) => String(n).padStart(2,'0');
  const filename = `REC_${now.getFullYear()}-${f(now.getMonth()+1)}-${f(now.getDate())}_${f(now.getHours())}${f(now.getMinutes())}.csv`;

  return (
    <div style={{
      position: 'fixed', inset: 0,
      background: 'rgba(0,0,0,0.65)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      zIndex: 100,
    }} onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()}
        style={{
          width: 520,
          background: TOKENS.panel,
          border: `1px solid ${TOKENS.border}`,
          borderTop: `2px solid ${TOKENS.accent}`,
          padding: 24,
          display: 'flex', flexDirection: 'column', gap: 18,
        }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 10, color: TOKENS.accent, letterSpacing: 1.4, fontWeight: 600,
          }}>NEW RECORDING</span>
          <span style={{ flex: 1 }} />
          <button onClick={onClose}
            style={{
              background: 'transparent', border: 'none',
              color: TOKENS.dim, cursor: 'pointer', fontSize: 18,
            }}>×</button>
        </div>
        <div style={{ fontSize: 16, color: TOKENS.text, fontWeight: 500 }}>
          레코딩 메타데이터 입력
        </div>
        <DialogField label="블록 ID" value={block} onChange={setBlock} mono />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <DialogField label="셀" value={cell} onChange={setCell} mono />
          <DialogField label="패스 (현재/총)" value={path} onChange={setPath} mono />
        </div>
        <DialogField label="작업자" value={operator} onChange={setOperator} />
        <DialogField label="메모 (선택)" value={note} onChange={setNote}
          placeholder="이 레코딩에 대한 메모" />
        <div style={{
          padding: 10,
          background: TOKENS.bg,
          border: `1px solid ${TOKENS.border}`,
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 10, color: TOKENS.dim, lineHeight: 1.5,
        }}>
          <div style={{ color: TOKENS.text, marginBottom: 4 }}>
            ▸ {filename}
          </div>
          /var/shipyard/recordings/<br />
          RTDE 125Hz + Modbus 4Hz (timestamp 보간 후 병합)
        </div>
        <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
          <button onClick={onClose} style={btnSecondary}>취소</button>
          <button onClick={() => onConfirm({ name: filename, block, cell, path, operator, note })}
            style={btnPrimary}>
            ● 시작
          </button>
        </div>
      </div>
    </div>
  );
}

function DialogField({ label, value, onChange, mono, placeholder }) {
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
      <span style={{
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 9, color: TOKENS.muted, letterSpacing: 1,
      }}>{label}</span>
      <input value={value} onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        style={{
          background: TOKENS.bg,
          border: `1px solid ${TOKENS.border}`,
          color: TOKENS.text,
          padding: '8px 10px',
          fontFamily: mono ? 'JetBrains Mono, monospace' : 'inherit',
          fontSize: 12,
          borderRadius: 2,
          outline: 'none',
        }} />
    </label>
  );
}

const btnPrimary = {
  padding: '8px 18px',
  background: TOKENS.accent,
  color: '#0a0f1c',
  border: 'none',
  fontFamily: 'JetBrains Mono, monospace',
  fontSize: 11, letterSpacing: 0.8, fontWeight: 600,
  cursor: 'pointer',
  borderRadius: 2,
};
const btnSecondary = {
  padding: '8px 18px',
  background: 'transparent',
  color: TOKENS.dim,
  border: `1px solid ${TOKENS.border}`,
  fontFamily: 'JetBrains Mono, monospace',
  fontSize: 11, letterSpacing: 0.8,
  cursor: 'pointer',
  borderRadius: 2,
};

function RecordingTable({ rows, activeRecId, onOpen }) {
  return (
    <div style={{
      background: TOKENS.panel,
      border: `1px solid ${TOKENS.border}`,
      borderRadius: 2,
      overflow: 'hidden',
    }}>
      <div style={{
        display: 'grid',
        gridTemplateColumns: '32px 1fr 80px 60px 80px 100px 90px 120px 100px 70px 140px',
        gap: 12,
        padding: '10px 16px',
        background: TOKENS.panel2,
        borderBottom: `1px solid ${TOKENS.border}`,
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 9, color: TOKENS.muted, letterSpacing: 0.8,
      }}>
        <span>SRC</span>
        <span>FILE / ID</span>
        <span>BLOCK</span>
        <span>CELL</span>
        <span>PATH</span>
        <span>OPERATOR</span>
        <span>DURATION</span>
        <span>SAMPLES</span>
        <span>SIZE</span>
        <span style={{ textAlign:'center' }}>ALARM</span>
        <span style={{ textAlign:'right' }}>ACTIONS</span>
      </div>
      {rows.map(r => {
        const isActive = r.id === activeRecId;
        return (
          <div key={r.id}
            style={{
              display: 'grid',
              gridTemplateColumns: '32px 1fr 80px 60px 80px 100px 90px 120px 100px 70px 140px',
              gap: 12,
              padding: '12px 16px',
              alignItems: 'center',
              borderBottom: `1px solid ${TOKENS.border}33`,
              background: isActive ? TOKENS.accent + '08' : 'transparent',
              borderLeft: isActive ? `2px solid ${TOKENS.accent}` : `2px solid transparent`,
              fontFamily: 'JetBrains Mono, monospace',
              fontSize: 11,
            }}>
            <span style={{
              padding: '2px 5px',
              borderRadius: 1, fontSize: 9, fontWeight: 600,
              background: r.source === 'db' ? TOKENS.violet + '22' : TOKENS.cyan + '22',
              color: r.source === 'db' ? TOKENS.violet : TOKENS.cyan,
              textAlign: 'center',
              letterSpacing: 0.6,
            }}>{r.source.toUpperCase()}</span>
            <div style={{ minWidth: 0 }}>
              <div style={{
                color: TOKENS.text,
                overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                display: 'flex', alignItems: 'center', gap: 6,
              }}>
                {r.starred && <span style={{ color: TOKENS.amber }}>★</span>}
                <span>{r.name}</span>
              </div>
              <div style={{
                fontSize: 9, color: TOKENS.muted, marginTop: 2,
                overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
              }}>{r.startedAt} · {r.note}</div>
            </div>
            <span style={{ color: TOKENS.text }}>{r.block}</span>
            <span style={{ color: TOKENS.cyan }}>{r.cell}</span>
            <span style={{ color: TOKENS.text }}>{r.path}</span>
            <span style={{ color: TOKENS.dim, fontFamily: 'Pretendard, sans-serif', fontSize: 11 }}>{r.operator}</span>
            <span style={{ color: TOKENS.text }}>{fmtT(r.duration)}</span>
            <span style={{ color: TOKENS.dim }}>{r.samples.toLocaleString()}</span>
            <span style={{ color: TOKENS.dim }}>{r.size}</span>
            <span style={{
              textAlign:'center',
              color: r.alarms === 0 ? TOKENS.green : r.alarms > 5 ? TOKENS.red : TOKENS.amber,
              fontWeight: 600,
            }}>{r.alarms}</span>
            <div style={{
              display: 'flex', gap: 4, justifyContent: 'flex-end',
            }}>
              <button onClick={() => onOpen(r.id)}
                style={{
                  padding: '4px 10px',
                  background: isActive ? TOKENS.accent : 'transparent',
                  color: isActive ? '#0a0f1c' : TOKENS.accent,
                  border: `1px solid ${TOKENS.accent}`,
                  fontFamily: 'JetBrains Mono, monospace',
                  fontSize: 10, letterSpacing: 0.6, fontWeight: 600,
                  cursor: 'pointer',
                  borderRadius: 1,
                }}>
                {isActive ? '열림' : '분석 열기'}
              </button>
              <button style={iconBtn} title="다운로드">⤓</button>
              <button style={iconBtn} title="삭제">×</button>
            </div>
          </div>
        );
      })}
    </div>
  );
}

const iconBtn = {
  padding: '4px 8px',
  background: 'transparent',
  color: TOKENS.dim,
  border: `1px solid ${TOKENS.border}`,
  fontFamily: 'JetBrains Mono, monospace',
  fontSize: 11,
  cursor: 'pointer',
  borderRadius: 1,
};

window.ScreenRecordings = ScreenRecordings;
