// Modbus register table for the welding robot. Addresses 128~255.
// Grouped by direction (로봇 → 팬던트, 팬던트 → 로봇, etc.).
// Live values are simulated; in production they would come from the
// backend's modbus_client.py polling loop.

(function () {
  // ─── Register definitions ────────────────────────────────────────────
  // group: 'rp' (로봇 → 팬던트), 'pr' (팬던트 → 로봇),
  //        'rw' (로봇 → 용접기), 'wr' (용접기 → 로봇),
  //        'pc' (팬던트 → 로봇 · 용접 조건)
  // status: 'active' | 'reserved' | 'unused'  (현재 사용 안함)
  // kind:   'counter' | 'bool' | 'enum' | 'value' | 'code' | 'bitfield' | 'string'

  const R = [
    // ── 128~160 (로봇 → 팬던트)
    { a:128, name:'하트비트',                en:'heartbeat',           grp:'rp', unit:'',     kind:'counter', range:[0,500], status:'active', desc:'1초 간격 1씩 증가' },
    { a:129, name:'프로그램 동작 여부',       en:'program_run',         grp:'rp', unit:'',     kind:'bool',    range:[0,1],   status:'unused', desc:'1=동작, 0=X' },
    { a:130, name:'용접 여부',               en:'welding',             grp:'rp', unit:'',     kind:'bool',    range:[0,1],   status:'active', desc:'1=용접 중, 0=무부하' },
    { a:131, name:'현재 전류',               en:'cur_current',         grp:'rp', unit:'A',    kind:'value',   range:[0,600], status:'active', desc:'실제 용접 전류' },
    { a:132, name:'현재 전압',               en:'cur_voltage',         grp:'rp', unit:'V',    kind:'value',   range:[0,80],  status:'active', desc:'실제 용접 전압' },
    { a:133, name:'지령 전류',               en:'set_current',         grp:'rp', unit:'A',    kind:'value',   range:[0,600], status:'active', desc:'설정 용접 전류' },
    { a:134, name:'지령 전압',               en:'set_voltage',         grp:'rp', unit:'V',    kind:'value',   range:[0,80],  status:'active', desc:'설정 용접 전압' },
    { a:135, name:'현재 PATH 셀',            en:'cur_cell',            grp:'rp', unit:'',     kind:'enum',    enums:['VL1','VL2','VR1','VR2','HOR'], status:'active', desc:'현재 용접 셀' },
    { a:136, name:'현재 PATH',               en:'cur_path',            grp:'rp', unit:'',     kind:'value',   range:[1,5],   status:'active', desc:'현재 멀티 패스 번호' },
    { a:137, name:'용접 종료',               en:'weld_end',            grp:'rp', unit:'',     kind:'bool',    range:[0,1],   status:'active', desc:'1=종료' },
    { a:138, name:'전체 중 현재 PATH',       en:'cur_path_idx',        grp:'rp', unit:'',     kind:'value',   range:[0,7],   status:'active', desc:'전체 패스 중 현재 인덱스' },
    { a:139, name:'전체 PATH',               en:'total_path',          grp:'rp', unit:'',     kind:'value',   range:[1,7],   status:'active', desc:'총 패스 개수' },
    { a:140, name:'2F 개수',                 en:'count_2f',            grp:'rp', unit:'',     kind:'value',   range:[1,3],   status:'active', desc:'2F 멀티패스 개수' },
    { a:141, name:'로봇 준비',               en:'robot_ready',         grp:'rp', unit:'',     kind:'bool',    range:[0,1],   status:'unused', desc:'1=준비 중' },
    { a:142, name:'로봇 에러',               en:'robot_error',         grp:'rp', unit:'code', kind:'code',    range:[0,255], status:'active', desc:'로봇 에러 코드' },
    { a:143, name:'현재 시간',               en:'cur_time',            grp:'rp', unit:'',     kind:'value',   range:[0,9999],status:'unused', desc:'현재 시간' },
    { a:144, name:'전체 시간',               en:'total_time',          grp:'rp', unit:'',     kind:'value',   range:[0,9999],status:'unused', desc:'전체 시간' },
    { a:145, name:'셀 번호',                 en:'cell_num',            grp:'rp', unit:'',     kind:'value',   range:[0,255], status:'unused', desc:'' },
    { a:146, name:'셀 요청',                 en:'cell_req',            grp:'rp', unit:'',     kind:'value',   range:[0,255], status:'unused', desc:'' },
    { a:147, name:'Reserved',                en:'rsv_147',             grp:'rp', unit:'',     kind:'value',   range:[0,0],   status:'reserved', desc:'작업 시트 공란' },
    { a:148, name:'Reserved',                en:'rsv_148',             grp:'rp', unit:'',     kind:'value',   range:[0,0],   status:'reserved', desc:'작업 시트 공란' },
    { a:149, name:'(임시) 용접기 제어 기록',  en:'tmp_weld_ctrl_log',   grp:'rp', unit:'',     kind:'value',   range:[0,255], status:'active', desc:'용접기 제어 기록 (임시)' },
    { a:150, name:'Reserved',                en:'rsv_150',             grp:'rp', unit:'',     kind:'value',   range:[0,0],   status:'reserved', desc:'작업 시트 공란' },
    { a:151, name:'셀 선택 FLAG',            en:'cell_flag',           grp:'rp', unit:'',     kind:'enum',    enums:['VL1','VL2','VR1','VR2','HOR'], status:'active', desc:'셀 선택 플래그' },
    { a:152, name:'기타 정보',               en:'misc_info',           grp:'rp', unit:'',     kind:'value',   range:[0,255], status:'active', desc:'2F 멀티패스 정보' },
    { a:153, name:'용접 조건 요청',          en:'req_weld_cond',       grp:'rp', unit:'',     kind:'bool',    range:[0,1],   status:'active', desc:'1=요청' },
    { a:154, name:'정보 수신 완료',          en:'cond_rx_ack',         grp:'rp', unit:'',     kind:'bool',    range:[0,1],   status:'active', desc:'1=완료' },
    { a:155, name:'터치셀',                  en:'touch_cell',          grp:'rp', unit:'',     kind:'enum',    enums:['VL1','VL2','VR1','VR2','HOR'], status:'active', desc:'현재 터치 대상 셀' },
    { a:156, name:'터치 번호',               en:'touch_num',           grp:'rp', unit:'',     kind:'value',   range:[1,4],   status:'active', desc:'2F/3F별 의미 다름' },
    { a:157, name:'터치 완료',               en:'touch_done',          grp:'rp', unit:'',     kind:'bool',    range:[0,1],   status:'active', desc:'터치 수행 완료' },
    { a:158, name:'전압_END',                en:'voltage_end',         grp:'rp', unit:'V',    kind:'value',   range:[0,80],  status:'active', desc:'종료/중간갭 전압' },
    { a:159, name:'전류_END',                en:'current_end',         grp:'rp', unit:'A',    kind:'value',   range:[0,600], status:'active', desc:'종료/중간갭 전류' },
    { a:160, name:'로봇 버전',               en:'robot_ver',           grp:'rp', unit:'',     kind:'string',  range:[0,0],   status:'active', desc:'메이저.마이너.버그' },

    // ── 161~199 (팬던트 → 로봇)
    { a:161, name:'팬던트 하트비트',          en:'pendant_hb',          grp:'pr', unit:'',     kind:'counter', range:[0,500], status:'active', desc:'팬던트 통신 생존' },
    { a:162, name:'작업 모드',               en:'work_mode',           grp:'pr', unit:'',     kind:'enum',    enums:['수동','자동'], status:'active', desc:'1=수동, 2=자동' },
    { a:163, name:'로봇 이동',               en:'robot_move',          grp:'pr', unit:'',     kind:'bool',    range:[0,1],   status:'active', desc:'1=이동 요청' },
    { a:164, name:'로봇 자세',               en:'robot_pose',          grp:'pr', unit:'',     kind:'value',   range:[1,4],   status:'active', desc:'로봇 자세/동작' },
    { a:165, name:'동작 모드',               en:'move_mode',           grp:'pr', unit:'',     kind:'enum',    enums:['치수','직접'], status:'active', desc:'1=치수, 2=직접' },
    { a:166, name:'이동 패스',               en:'move_path',           grp:'pr', unit:'',     kind:'value',   range:[1,7],   status:'active', desc:'이동할 패스 번호' },
    { a:167, name:'이동',                    en:'move_trig',           grp:'pr', unit:'',     kind:'bool',    range:[0,1],   status:'active', desc:'1=이동 트리거' },
    { a:168, name:'아크 온/오프',            en:'arc_onoff',           grp:'pr', unit:'',     kind:'enum',    enums:['아크오프','아크온'], status:'active', desc:'2=아크온, 1=아크오프' },
    { a:169, name:'스틱아웃',                en:'stickout',            grp:'pr', unit:'',     kind:'enum',    enums:['Plus','Minus'], status:'active', desc:'1=Plus, 2=Minus' },
    { a:170, name:'직접 교시 시작',          en:'teach_start',         grp:'pr', unit:'',     kind:'bool',    range:[0,1],   status:'active', desc:'1=시작' },
    { a:171, name:'선택 셀 좌',              en:'sel_cell_l',          grp:'pr', unit:'',     kind:'value',   range:[1,8],   status:'active', desc:'좌측 셀' },
    { a:172, name:'선택 셀 우',              en:'sel_cell_r',          grp:'pr', unit:'',     kind:'value',   range:[1,8],   status:'active', desc:'우측 셀' },
    { a:173, name:'수직좌',                  en:'vert_l',              grp:'pr', unit:'mm',   kind:'value',   range:[0,1000],status:'active', desc:'좌측 수직 치수' },
    { a:174, name:'수직우',                  en:'vert_r',              grp:'pr', unit:'mm',   kind:'value',   range:[0,1000],status:'active', desc:'우측 수직 치수' },
    { a:175, name:'수평 바닥',               en:'horiz_bottom',        grp:'pr', unit:'mm',   kind:'value',   range:[0,1000],status:'active', desc:'바닥 수평 치수' },
    { a:176, name:'스칼럽 상',               en:'scallop_top',         grp:'pr', unit:'',     kind:'value',   range:[0,255], status:'active', desc:'2F=왼쪽 / 3F=위' },
    { a:177, name:'스칼럽 하',               en:'scallop_bot',         grp:'pr', unit:'',     kind:'value',   range:[0,255], status:'active', desc:'2F=오른쪽 / 3F=안씀' },
    { a:178, name:'셀 선택',                 en:'cell_sel',            grp:'pr', unit:'',     kind:'bitfield',range:[0,255], status:'active', desc:'선택된 셀 플래그' },
    { a:179, name:'EXT_FLAG',                en:'ext_flag',            grp:'pr', unit:'',     kind:'bitfield',range:[0,255], status:'active', desc:'정밀터치 · 이음용접 · 스티프너' },
    { a:180, name:'터치위치 기억',           en:'touch_memo',          grp:'pr', unit:'',     kind:'bool',    range:[0,1],   status:'active', desc:'1=과거 터치 사용' },
    { a:181, name:'칼라 가로',               en:'collar_w',            grp:'pr', unit:'',     kind:'value',   range:[0,1000],status:'active', desc:'칼라 가로 치수' },
    { a:182, name:'칼라 세로',               en:'collar_h',            grp:'pr', unit:'',     kind:'value',   range:[0,1000],status:'active', desc:'칼라 세로 치수' },
    { a:183, name:'각장_2f',                 en:'legsz_2f',            grp:'pr', unit:'',     kind:'value',   range:[6,11],  status:'active', desc:'2F 각장 (멀티패스 여부)' },
    { a:184, name:'상하 P gain',             en:'p_gain_uz',           grp:'pr', unit:'×10',  kind:'value',   range:[0,1000],status:'active', desc:'상하축 P gain' },
    { a:185, name:'상하 I gain',             en:'i_gain_uz',           grp:'pr', unit:'×10',  kind:'value',   range:[0,1000],status:'active', desc:'상하축 I gain' },
    { a:186, name:'좌우 P gain',             en:'p_gain_lr',           grp:'pr', unit:'×10',  kind:'value',   range:[0,1000],status:'active', desc:'좌우축 P gain' },
    { a:187, name:'좌우 I gain',             en:'i_gain_lr',           grp:'pr', unit:'×10',  kind:'value',   range:[0,1000],status:'active', desc:'좌우축 I gain' },
    { a:188, name:'곡블럭 옵션1',            en:'curve_opt1',          grp:'pr', unit:'',     kind:'bitfield',range:[0,255], status:'active', desc:'좌/우 Longi · 용접방향' },
    { a:189, name:'곡블럭 옵션2',            en:'curve_opt2',          grp:'pr', unit:'',     kind:'bitfield',range:[0,255], status:'active', desc:'구간별 보정값 packed' },
    { a:190, name:'중간갭_속도1',            en:'gap_speed1',          grp:'pr', unit:'×10',  kind:'value',   range:[0,1000],status:'unused', desc:'4.7V 평블록 미사용' },
    { a:191, name:'Reserved',                en:'rsv_191',             grp:'pr', unit:'',     kind:'value',   range:[0,0],   status:'reserved', desc:'' },
    { a:192, name:'중간갭_진폭1',            en:'gap_amp1',            grp:'pr', unit:'×10',  kind:'value',   range:[0,1000],status:'unused', desc:'4.7V 평블록 미사용' },
    { a:193, name:'Reserved',                en:'rsv_193',             grp:'pr', unit:'',     kind:'value',   range:[0,0],   status:'reserved', desc:'' },
    { a:194, name:'중간갭_전류1',            en:'gap_curr1',           grp:'pr', unit:'×10',  kind:'value',   range:[0,1000],status:'unused', desc:'4.7V 평블록 미사용' },
    { a:195, name:'Reserved',                en:'rsv_195',             grp:'pr', unit:'',     kind:'value',   range:[0,0],   status:'reserved', desc:'' },
    { a:196, name:'중간갭_전압1',            en:'gap_volt1',           grp:'pr', unit:'×10',  kind:'value',   range:[0,1000],status:'unused', desc:'4.7V 평블록 미사용' },
    { a:197, name:'Reserved',                en:'rsv_197',             grp:'pr', unit:'',     kind:'value',   range:[0,0],   status:'reserved', desc:'' },
    { a:198, name:'바닥각도',                en:'bottom_angle',        grp:'pr', unit:'',     kind:'value',   range:[0,8],   status:'unused', desc:'0=중앙, 1=왼쪽, 2=오른쪽, 3~8=각도대' },
    { a:199, name:'Reserved',                en:'rsv_199',             grp:'pr', unit:'',     kind:'value',   range:[0,0],   status:'reserved', desc:'' },

    // ── 201~210 (로봇 → 용접기)
    { a:201, name:'로봇 사용',               en:'robot_use',           grp:'rw', unit:'',     kind:'bool',    range:[0,1],   status:'active', desc:'1=모드버스 사용' },
    { a:202, name:'용접기 제어',             en:'welder_ctrl',         grp:'rw', unit:'',     kind:'bitfield',range:[0,255], status:'active', desc:'용접기 제어 비트필드' },
    { a:203, name:'와이어 정보',             en:'wire_info',           grp:'rw', unit:'',     kind:'value',   range:[0,255], status:'active', desc:'와이어 정보 (구 명칭: 용접 속도)' },
    { a:204, name:'전류 설정',               en:'set_current_t',       grp:'rw', unit:'A',    kind:'value',   range:[0,600], status:'active', desc:'목표 전류' },
    { a:205, name:'전압 설정',               en:'set_voltage_t',       grp:'rw', unit:'V',    kind:'value',   range:[0,80],  status:'active', desc:'목표 전압' },
    { a:206, name:'전압 시너지 보정',        en:'synergy_v',           grp:'rw', unit:'',     kind:'value',   range:[-50,50],status:'active', desc:'시너지 보정값' },
    { a:207, name:'Reserved',                en:'rsv_207',             grp:'rw', unit:'',     kind:'value',   range:[0,0],   status:'reserved', desc:'' },
    { a:208, name:'Reserved',                en:'rsv_208',             grp:'rw', unit:'',     kind:'value',   range:[0,0],   status:'reserved', desc:'' },
    { a:209, name:'Reserved',                en:'rsv_209',             grp:'rw', unit:'',     kind:'value',   range:[0,0],   status:'reserved', desc:'' },
    { a:210, name:'Reserved',                en:'rsv_210',             grp:'rw', unit:'',     kind:'value',   range:[0,0],   status:'reserved', desc:'' },

    // ── 211~220 (용접기 → 로봇)
    { a:211, name:'WCR 검출 / STICK',        en:'wcr_stick',           grp:'wr', unit:'',     kind:'bitfield',range:[0,255], status:'active', desc:'용접기 상태 피드백' },
    { a:212, name:'용접 전류 피드백',         en:'fb_current',          grp:'wr', unit:'A',    kind:'value',   range:[0,600], status:'active', desc:'실제 전류 피드백' },
    { a:213, name:'용접 전압 피드백',         en:'fb_voltage',          grp:'wr', unit:'V',    kind:'value',   range:[0,80],  status:'active', desc:'실제 전압 피드백' },
    { a:214, name:'송급장치 상태',            en:'feeder_state',        grp:'wr', unit:'m/min',kind:'value',   range:[0,18],  status:'active', desc:'와이어 송급 속도' },
    { a:215, name:'와이어 정보',              en:'fb_wire_info',        grp:'wr', unit:'',     kind:'value',   range:[0,255], status:'active', desc:'와이어 상태' },
    { a:216, name:'용접기 오류',              en:'welder_error',        grp:'wr', unit:'code', kind:'code',    range:[0,255], status:'active', desc:'용접기 오류 코드' },
    { a:217, name:'출력 전류 설정',           en:'out_set_current',     grp:'wr', unit:'A',    kind:'value',   range:[0,600], status:'active', desc:'전류 설정값 피드백' },
    { a:218, name:'출력 전압 설정',           en:'out_set_voltage',     grp:'wr', unit:'V',    kind:'value',   range:[0,80],  status:'active', desc:'전압 설정값 피드백' },
    { a:219, name:'전압 시너지 보정',         en:'fb_synergy',          grp:'wr', unit:'',     kind:'value',   range:[-50,50],status:'active', desc:'시너지 피드백' },
    { a:220, name:'용접 파라미터1',           en:'weld_param1',         grp:'wr', unit:'',     kind:'value',   range:[0,255], status:'active', desc:'파라미터1' },

    // ── 221~255 (팬던트 → 로봇 · 용접 조건)
    { a:221, name:'용접 파라미터2',           en:'weld_param2',         grp:'pc', unit:'',     kind:'value',   range:[0,255], status:'active', desc:'파라미터2' },
    { a:222, name:'용접 파라미터3',           en:'weld_param3',         grp:'pc', unit:'',     kind:'value',   range:[0,255], status:'active', desc:'파라미터3' },
    { a:223, name:'Reserved',                 en:'rsv_223',             grp:'pc', unit:'',     kind:'value',   range:[0,0],   status:'reserved', desc:'' },
    { a:224, name:'Reserved',                 en:'rsv_224',             grp:'pc', unit:'',     kind:'value',   range:[0,0],   status:'reserved', desc:'' },
    { a:225, name:'주파수',                   en:'weave_freq',          grp:'pc', unit:'Hz',   kind:'value',   range:[0,100], status:'active', desc:'위빙 주파수' },
    { a:226, name:'바닥 멈춤 시간',           en:'dwell_bottom',        grp:'pc', unit:'s',    kind:'value',   range:[0,10],  status:'active', desc:'바닥 dwell time' },
    { a:227, name:'벽 멈춤 시간',             en:'dwell_wall',          grp:'pc', unit:'s',    kind:'value',   range:[0,10],  status:'active', desc:'벽 dwell time' },
    { a:228, name:'작업각',                   en:'work_angle',          grp:'pc', unit:'°',    kind:'value',   range:[0,90],  status:'active', desc:'작업 각도' },
    { a:229, name:'x 오프셋',                 en:'x_offset',            grp:'pc', unit:'×10mm',kind:'value',   range:[-50,50],status:'active', desc:'X offset' },
    { a:230, name:'z 오프셋',                 en:'z_offset',            grp:'pc', unit:'×10mm',kind:'value',   range:[-50,50],status:'active', desc:'Z offset' },
    { a:231, name:'전압 (지령)',              en:'cond_voltage',        grp:'pc', unit:'×10V', kind:'value',   range:[0,800], status:'active', desc:'지령 전압' },
    { a:232, name:'전류 (지령)',              en:'cond_current',        grp:'pc', unit:'×10A', kind:'value',   range:[0,6000],status:'active', desc:'지령 전류' },
    { a:233, name:'속도_start',               en:'speed_start',         grp:'pc', unit:'×10cpm',kind:'value',  range:[0,1000],status:'active', desc:'시작 속도' },
    { a:234, name:'위빙폭_start',             en:'weave_w_start',       grp:'pc', unit:'×10mm',kind:'value',   range:[0,500], status:'active', desc:'시작 위빙폭' },
    { a:235, name:'속도_end',                 en:'speed_end',           grp:'pc', unit:'×10cpm',kind:'value',  range:[0,1000],status:'active', desc:'종료 속도' },
    { a:236, name:'위빙폭_end',               en:'weave_w_end',         grp:'pc', unit:'×10mm',kind:'value',   range:[0,500], status:'active', desc:'종료 위빙폭' },
    { a:237, name:'방향 탐색 높이',           en:'dir_search_h',        grp:'pc', unit:'mm',   kind:'value',   range:[0,50],  status:'active', desc:'' },
    { a:238, name:'터치 높이',                en:'touch_h',             grp:'pc', unit:'mm',   kind:'value',   range:[0,50],  status:'active', desc:'' },
    { a:239, name:'아크센싱',                 en:'arc_sensing',         grp:'pc', unit:'A',    kind:'value',   range:[0,600], status:'unused', desc:'4.7V 평블록 미사용' },
    { a:240, name:'로봇 반환 완료',           en:'robot_ack',           grp:'pc', unit:'',     kind:'bool',    range:[0,1],   status:'active', desc:'1=반환 완료' },
    { a:241, name:'시작 용접시간',            en:'start_t',             grp:'pc', unit:'×10s', kind:'value',   range:[0,200], status:'active', desc:'시작 조건: 시간' },
    { a:242, name:'시작 가스',                en:'start_gas',           grp:'pc', unit:'×10s', kind:'value',   range:[0,200], status:'unused', desc:'4.7V 평블록 미사용' },
    { a:243, name:'시작 후진 거리',           en:'start_back',          grp:'pc', unit:'mm',   kind:'value',   range:[0,100], status:'unused', desc:'4.7V 평블록 미사용' },
    { a:244, name:'시작 전류',                en:'start_current',       grp:'pc', unit:'×10A', kind:'value',   range:[0,6000],status:'active', desc:'시작 조건: 전류' },
    { a:245, name:'시작 전압',                en:'start_voltage',       grp:'pc', unit:'×10V', kind:'value',   range:[0,800], status:'active', desc:'시작 조건: 전압' },
    { a:246, name:'끝 용접시간',              en:'end_t',               grp:'pc', unit:'×10s', kind:'value',   range:[0,200], status:'active', desc:'끝 조건: 시간' },
    { a:247, name:'끝 가스',                  en:'end_gas',             grp:'pc', unit:'×10s', kind:'value',   range:[0,200], status:'active', desc:'끝 조건: 가스' },
    { a:248, name:'끝 후진 거리',             en:'end_back',            grp:'pc', unit:'mm',   kind:'value',   range:[0,100], status:'active', desc:'끝 조건: 후진' },
    { a:249, name:'끝 전류',                  en:'end_current',         grp:'pc', unit:'×10A', kind:'value',   range:[0,6000],status:'active', desc:'끝 조건: 전류' },
    { a:250, name:'끝 전압',                  en:'end_voltage',         grp:'pc', unit:'×10V', kind:'value',   range:[0,800], status:'active', desc:'끝 조건: 전압' },
    { a:251, name:'끝 용접시간2',             en:'end_t2',              grp:'pc', unit:'×10s', kind:'value',   range:[0,200], status:'active', desc:'끝 조건2: 시간' },
    { a:252, name:'끝 가스2',                 en:'end_gas2',            grp:'pc', unit:'×10s', kind:'value',   range:[0,200], status:'active', desc:'끝 조건2: 가스' },
    { a:253, name:'끝 후진 거리2',            en:'end_back2',           grp:'pc', unit:'mm',   kind:'value',   range:[0,100], status:'active', desc:'끝 조건2: 후진' },
    { a:254, name:'끝 전류2',                 en:'end_current2',        grp:'pc', unit:'×10A', kind:'value',   range:[0,6000],status:'active', desc:'끝 조건2: 전류' },
    { a:255, name:'끝 전압2',                 en:'end_voltage2',        grp:'pc', unit:'×10V', kind:'value',   range:[0,800], status:'active', desc:'끝 조건2: 전압' },
  ];

  // ─── Group metadata ──────────────────────────────────────────────────
  const groups = {
    rp: { id:'rp', label:'로봇 → 팬던트',  short:'R→P',  range:'128–160', color:'#ff6b35', desc:'로봇 상태 보고' },
    pr: { id:'pr', label:'팬던트 → 로봇',  short:'P→R',  range:'161–199', color:'#22d3ee', desc:'팬던트 지시' },
    rw: { id:'rw', label:'로봇 → 용접기',  short:'R→W',  range:'201–210', color:'#fbbf24', desc:'용접기 설정' },
    wr: { id:'wr', label:'용접기 → 로봇',  short:'W→R',  range:'211–220', color:'#34d399', desc:'용접기 피드백' },
    pc: { id:'pc', label:'용접 조건 (P→R)', short:'COND', range:'221–255', color:'#a78bfa', desc:'용접 조건 파라미터' },
  };

  // ─── Live value simulator ───────────────────────────────────────────
  // Hooks set up a 250ms ticker that animates a handful of "active" registers
  // so the dashboard feels alive without being chaotic.

  const initialState = {};
  R.forEach(r => {
    if (r.status !== 'active') { initialState[r.a] = 0; return; }
    if (r.kind === 'counter') initialState[r.a] = 0;
    else if (r.kind === 'bool') initialState[r.a] = 0;
    else if (r.kind === 'enum') initialState[r.a] = 1;
    else if (r.kind === 'code') initialState[r.a] = 0;
    else if (r.kind === 'string') initialState[r.a] = '4.7.2';
    else initialState[r.a] = (r.range?.[0] + r.range?.[1]) / 2 || 0;
  });

  // Reasonable default snapshot (welding active on cell VL2, path 2/3)
  Object.assign(initialState, {
    128: 1, 130: 1, 131: 218, 132: 24.1, 133: 220, 134: 24,
    135: 'VL2', 136: 2, 138: 2, 139: 3, 140: 2, 142: 0,
    151: 'VL2', 155: 'VL2', 156: 1, 158: 22.5, 159: 195,
    160: '4.7.2',
    161: 1, 162: 2, 168: 2,
    173: 280, 174: 280, 175: 220, 183: 8,
    184: 80, 185: 30, 186: 70, 187: 25,
    201: 1, 204: 220, 205: 24, 206: 0,
    211: 5, 212: 218, 213: 24.1, 214: 9.2, 216: 0,
    217: 220, 218: 24, 219: 0,
    225: 1.6, 226: 0.3, 227: 0.4, 228: 45,
    229: 0, 230: 0, 231: 240, 232: 2200,
    233: 35, 234: 25, 235: 35, 236: 25,
    237: 8, 238: 5,
    241: 5, 244: 2200, 245: 240,
    246: 5, 247: 8, 248: 8, 249: 2000, 250: 220,
    251: 3, 252: 5, 253: 5, 254: 1800, 255: 200,
  });

  // ─── API ─────────────────────────────────────────────────────────────
  // Subscribers receive a fresh state object every tick. The simulator
  // mutates a small set of values per tick so charts and pulses look alive.

  const state = { ...initialState };
  const subs = new Set();
  let tick = 0;
  let started = false;

  function step() {
    tick++;
    state[128] = (state[128] + 1) % 500;        // robot heartbeat
    state[161] = (state[161] + 1) % 500;        // pendant heartbeat
    // Welding telemetry oscillates with a slow drift
    const t = tick * 0.25;
    const osc = Math.sin(t * 1.7) * 4 + (Math.random() - 0.5) * 3;
    state[131] = +(220 + osc).toFixed(1);
    state[132] = +(24.2 + Math.sin(t * 1.9) * 0.5 + (Math.random() - 0.5) * 0.3).toFixed(2);
    state[212] = +(state[131] + (Math.random() - 0.5) * 1.5).toFixed(1);
    state[213] = +(state[132] + (Math.random() - 0.5) * 0.15).toFixed(2);
    state[214] = +(9.2 + Math.sin(t * 0.6) * 0.4).toFixed(2);
    state[158] = +(22.5 + Math.sin(t * 0.3) * 0.6).toFixed(2);
    state[159] = +(195 + Math.sin(t * 0.4) * 6).toFixed(1);
    state[219] = +(Math.sin(t * 0.2) * 0.5).toFixed(2);
    // WCR/STICK bitfield flips bits occasionally
    state[211] = (tick % 40 === 0) ? (state[211] === 5 ? 13 : 5) : state[211];

    subs.forEach(fn => fn(state, tick));
  }

  function start() {
    if (started) return;
    started = true;
    setInterval(step, 250);
  }

  function subscribe(fn) {
    subs.add(fn);
    fn(state, tick);
    return () => subs.delete(fn);
  }

  // History buffer (last 240 ticks ≈ 60s) for sparklines
  const histLen = 240;
  const hist = {};
  R.forEach(r => { hist[r.a] = new Array(histLen).fill(state[r.a] || 0); });
  let histHead = 0;
  function pushHist() {
    R.forEach(r => {
      const v = state[r.a];
      hist[r.a][histHead] = typeof v === 'number' ? v : 0;
    });
    histHead = (histHead + 1) % histLen;
  }
  subs.add(() => pushHist());

  function getHist(addr) {
    const arr = hist[addr];
    const out = new Array(histLen);
    for (let i = 0; i < histLen; i++) {
      out[i] = arr[(histHead + i) % histLen];
    }
    return out;
  }

  window.MODBUS = {
    registers: R,
    groups,
    state,
    subscribe,
    start,
    getHist,
    byAddr: Object.fromEntries(R.map(r => [r.a, r])),
  };
})();
