// App shell: top chrome + left sidebar nav + main screen area.
// Manages global recording state (recording / stopped) and currently
// open recording (for the Analysis screen).

const NAV = [
  { id: 'monitoring', label: '실시간 모니터링', sub: 'Modbus TCP', icon: '◉' },
  { id: 'recordings', label: '레코딩',           sub: 'RTDE',         icon: '▭' },
  { id: 'analysis',   label: '분석 워크스페이스', sub: '사후 차트',     icon: '⟁' },
  { id: 'mapping',    label: 'GP 매핑',          sub: 'YAML',          icon: '⌥' },
];

// Sample recording library — used by the Recordings screen and as the
// "currently loaded" recording for the Analysis screen.
const RECORDING_LIBRARY = [
  {
    id: 'rec_001',
    name: 'REC_2026-05-13_0937.csv',
    block: 'BH-12',
    cell: 'VL2',
    path: '2/3',
    operator: '김재성',
    startedAt: '2026-05-13 09:37:21',
    duration: 598,
    samples: 74750,
    size: '4.2 MB',
    alarms: 6,
    source: 'file',
    note: '필렛 용접 · 2F 멀티패스 중간 정지 발생',
    starred: true,
  },
  {
    id: 'rec_002',
    name: 'REC_2026-05-13_0813.csv',
    block: 'BH-12',
    cell: 'VL1',
    path: '1/2',
    operator: '김재성',
    startedAt: '2026-05-13 08:13:44',
    duration: 412,
    samples: 51500,
    size: '2.9 MB',
    alarms: 0,
    source: 'file',
    note: '정상 완료',
  },
  {
    id: 'rec_003',
    name: 'REC_2026-05-12_1641.csv',
    block: 'BH-11',
    cell: 'HOR',
    path: '1/1',
    operator: '박지훈',
    startedAt: '2026-05-12 16:41:09',
    duration: 287,
    samples: 35875,
    size: '2.1 MB',
    alarms: 1,
    source: 'file',
    note: 'Z 오프셋 드리프트',
  },
  {
    id: 'rec_004',
    name: 'rec_db_2026-05-12_1402',
    block: 'BH-11',
    cell: 'VR1',
    path: '1/3',
    operator: '박지훈',
    startedAt: '2026-05-12 14:02:55',
    duration: 645,
    samples: 80625,
    size: '4.6 MB',
    alarms: 3,
    source: 'db',
    note: '아크 안정도 경고 2회',
  },
  {
    id: 'rec_005',
    name: 'rec_db_2026-05-12_0950',
    block: 'BH-10',
    cell: 'VR2',
    path: '2/4',
    operator: '이수민',
    startedAt: '2026-05-12 09:50:18',
    duration: 920,
    samples: 115000,
    size: '6.3 MB',
    alarms: 0,
    source: 'db',
    note: '정상 완료 · 장시간',
  },
  {
    id: 'rec_006',
    name: 'rec_db_2026-05-11_1715',
    block: 'BH-10',
    cell: 'VL2',
    path: '3/3',
    operator: '이수민',
    startedAt: '2026-05-11 17:15:02',
    duration: 503,
    samples: 62875,
    size: '3.5 MB',
    alarms: 12,
    source: 'db',
    note: 'X/Z 오프셋 다수 보정 · 검토 필요',
  },
];

function AppShell() {
  const [screen, setScreen] = React.useState('monitoring');
  const [activeRecId, setActiveRecId] = React.useState('rec_001'); // currently loaded in analysis
  // Recording session state — null when not recording
  const [session, setSession] = React.useState(null);

  // Start the modbus live ticker on mount
  React.useEffect(() => { window.MODBUS.start(); }, []);

  const openInAnalysis = (recId) => {
    setActiveRecId(recId);
    setScreen('analysis');
  };

  const startRecording = (meta) => {
    setSession({
      startedAt: Date.now(),
      meta,
      pausedTotal: 0,
      pausedAt: null,
    });
  };
  const stopRecording = () => setSession(null);

  // Tick session timer
  const [, force] = React.useReducer(x => x + 1, 0);
  React.useEffect(() => {
    if (!session) return;
    const id = setInterval(force, 500);
    return () => clearInterval(id);
  }, [session]);

  return (
    <div style={{
      width: '100vw', height: '100vh',
      background: TOKENS.bg,
      color: TOKENS.text,
      display: 'flex', flexDirection: 'column',
      fontFamily: 'Pretendard, -apple-system, sans-serif',
      overflow: 'hidden',
    }}>
      <TopChrome session={session} />
      <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
        <Sidebar
          screen={screen} setScreen={setScreen}
          session={session}
        />
        <main style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
          {screen === 'monitoring' && <ScreenMonitoring />}
          {screen === 'recordings' && (
            <ScreenRecordings
              library={RECORDING_LIBRARY}
              session={session}
              startRecording={startRecording}
              stopRecording={stopRecording}
              openInAnalysis={openInAnalysis}
              activeRecId={activeRecId}
            />
          )}
          {screen === 'analysis' && (
            <ScreenAnalysis
              recording={RECORDING_LIBRARY.find(r => r.id === activeRecId)}
              changeRecording={openInAnalysis}
              library={RECORDING_LIBRARY}
            />
          )}
          {screen === 'mapping' && <ScreenMapping />}
        </main>
      </div>
    </div>
  );
}

function TopChrome({ session }) {
  const elapsed = session ? Math.floor((Date.now() - session.startedAt) / 1000) : 0;
  return (
    <div style={{
      height: 44, flex: '0 0 auto',
      borderBottom: `1px solid ${TOKENS.border}`,
      background: TOKENS.panel2,
      display: 'flex', alignItems: 'center',
      padding: '0 16px', gap: 16,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{
          width: 22, height: 22,
          background: TOKENS.accent,
          clipPath: 'polygon(0 30%, 50% 0, 100% 30%, 100% 100%, 0 100%)',
        }} />
        <span style={{
          fontFamily: 'JetBrains Mono, monospace',
          fontWeight: 600, fontSize: 13,
          letterSpacing: 1.5,
          color: TOKENS.text,
        }}>SHIPYARD · WELD</span>
        <span style={{
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 10, color: TOKENS.muted,
          letterSpacing: 0.8,
        }}>v0.4.2</span>
      </div>

      <span style={{ flex: 1 }} />

      {session && (
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 8,
          padding: '4px 12px',
          background: TOKENS.red + '15',
          border: `1px solid ${TOKENS.red}55`,
          borderRadius: 2,
        }}>
          <span style={{
            width: 8, height: 8, borderRadius: '50%', background: TOKENS.red,
            boxShadow: `0 0 10px ${TOKENS.red}`,
            animation: 'pulse 1.2s ease-in-out infinite',
          }} />
          <span style={{
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 11, color: TOKENS.red, fontWeight: 600, letterSpacing: 0.8,
          }}>REC {fmtT(elapsed)}</span>
          <span style={{
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 10, color: TOKENS.text,
          }}>{session.meta?.name || ''}</span>
        </div>
      )}

      <ConnPill label="MODBUS · 192.168.1.40" ok />
      <ConnPill label="RTDE · UR10 PORT 30004" ok />
      <span style={{
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 10, color: TOKENS.dim,
        padding: '3px 8px',
        border: `1px solid ${TOKENS.border}`,
      }}>OPER · KIM J.S.</span>
      <LiveClock />

      <style>{`@keyframes pulse { 0%, 100% { opacity: 1 } 50% { opacity: 0.3 } }`}</style>
    </div>
  );
}

function Sidebar({ screen, setScreen, session }) {
  return (
    <aside style={{
      width: 220, flex: '0 0 auto',
      background: TOKENS.panel2,
      borderRight: `1px solid ${TOKENS.border}`,
      display: 'flex', flexDirection: 'column',
      padding: '14px 10px',
    }}>
      <div style={{
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 9, letterSpacing: 1.6,
        color: TOKENS.muted, padding: '0 8px 8px',
      }}>NAVIGATION</div>
      <nav style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {NAV.map(item => {
          const on = screen === item.id;
          return (
            <button key={item.id}
              onClick={() => setScreen(item.id)}
              style={{
                display: 'flex',
                alignItems: 'center', gap: 12,
                padding: '10px 10px',
                background: on ? TOKENS.bg : 'transparent',
                border: 'none',
                borderLeft: `2px solid ${on ? TOKENS.accent : 'transparent'}`,
                color: on ? TOKENS.text : TOKENS.dim,
                cursor: 'pointer',
                textAlign: 'left',
                borderRadius: 0,
              }}>
              <span style={{
                fontFamily: 'JetBrains Mono, monospace',
                fontSize: 14,
                color: on ? TOKENS.accent : TOKENS.dim,
                width: 16, textAlign: 'center',
              }}>{item.icon}</span>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 1, minWidth: 0 }}>
                <span style={{ fontSize: 12, whiteSpace: 'nowrap' }}>{item.label}</span>
                <span style={{
                  fontFamily: 'JetBrains Mono, monospace',
                  fontSize: 9, color: TOKENS.muted, letterSpacing: 0.6,
                  whiteSpace: 'nowrap',
                }}>{item.sub}</span>
              </div>
              {item.id === 'recordings' && session && (
                <span style={{
                  marginLeft: 'auto',
                  width: 6, height: 6, borderRadius: '50%',
                  background: TOKENS.red,
                  boxShadow: `0 0 6px ${TOKENS.red}`,
                }} />
              )}
            </button>
          );
        })}
      </nav>

      <div style={{ flex: 1 }} />

      <div style={{
        padding: 10,
        border: `1px solid ${TOKENS.border}`,
        background: TOKENS.bg,
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 10, color: TOKENS.dim,
        display: 'flex', flexDirection: 'column', gap: 4,
      }}>
        <div style={{ color: TOKENS.text, fontSize: 10, letterSpacing: 0.8 }}>
          SYSTEM
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span>샘플레이트</span><span style={{ color: TOKENS.text }}>125 Hz</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span>Modbus 폴링</span><span style={{ color: TOKENS.text }}>4 Hz</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span>레코딩 저장소</span><span style={{ color: TOKENS.text }}>62.3GB</span>
        </div>
        <div style={{
          height: 3, background: TOKENS.border, marginTop: 2, borderRadius: 1,
        }}>
          <div style={{
            width: '34%', height: '100%',
            background: TOKENS.green,
          }} />
        </div>
      </div>
    </aside>
  );
}

window.AppShell = AppShell;
window.RECORDING_LIBRARY = RECORDING_LIBRARY;
