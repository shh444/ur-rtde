// Screen: GP 매핑 (YAML 에디터)
// Raw YAML editor for the RTDE GP register → column mapping.
// Side preview shows parsed entries for sanity check.

function ScreenMapping() {
  const D = window.RTDE;

  const initialYaml = React.useMemo(() => {
    let s = '# gp_mapping.yaml\n';
    s += '# UR RTDE General Purpose register → 컬럼 매핑\n';
    s += '# backend/modbus_client.py 와 frontend 분석 UI 양쪽이 이 한 파일만 읽음\n';
    s += '#\n';
    s += '# 형식:\n';
    s += '#   <레지스터 이름>:\n';
    s += '#     col:   레코딩 CSV 컬럼명\n';
    s += '#     scale: float, 원시값에 곱할 스케일\n';
    s += '#     label: 한글 라벨 (차트/대시보드에 표시)\n';
    s += '#     unit:  단위 문자열\n\n';
    s += 'rtde:\n';
    s += '  host: 192.168.1.40\n';
    s += '  port: 30004\n';
    s += '  frequency: 125\n\n';
    s += 'mapping:\n';
    Object.entries(D.gpMapping).forEach(([reg, def]) => {
      s += `  ${reg}:\n`;
      s += `    col:   ${def.col}\n`;
      s += `    scale: ${def.scale}\n`;
      s += `    label: "${D.koLabels[def.col] || def.col}"\n`;
      s += `    unit:  "${D.units[def.col] || ''}"\n`;
    });
    s += '\nmodbus:\n';
    s += '  host: 192.168.1.40\n';
    s += '  unit_id: 1\n';
    s += '  poll_hz: 4\n';
    s += '  registers:\n';
    Object.entries(D.modbusLive).forEach(([k, v]) => {
      s += `    ${k}:\n`;
      s += `      unit:  "${v.unit}"\n`;
      s += `      range: [${v.range[0]}, ${v.range[1]}]\n`;
    });
    return s;
  }, [D]);

  const [yaml, setYaml] = React.useState(initialYaml);
  const [dirty, setDirty] = React.useState(false);
  const lines = yaml.split('\n');

  return (
    <div style={{
      flex: 1, display: 'grid',
      gridTemplateColumns: '1fr 400px',
      gap: 1, background: TOKENS.border,
      minHeight: 0,
    }}>
      {/* Editor */}
      <div style={{
        background: TOKENS.panel,
        display: 'flex', flexDirection: 'column',
        minHeight: 0,
      }}>
        <div style={{
          padding: '10px 14px',
          borderBottom: `1px solid ${TOKENS.border}`,
          display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <span style={{
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 11, color: TOKENS.text,
          }}>gp_mapping.yaml</span>
          <span style={{
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 10, color: TOKENS.dim,
          }}>· {lines.length} 줄 · {dirty ? '변경됨' : '저장됨'}</span>
          {dirty && <span style={{ width: 6, height: 6, background: TOKENS.amber, borderRadius: '50%' }} />}
          <span style={{ flex: 1 }} />
          <button style={mapBtn}>유효성 검사</button>
          <button style={mapBtn}>되돌리기</button>
          <button style={{ ...mapBtn, background: TOKENS.accent, color: '#0a0f1c', border: 'none', fontWeight: 600 }}
            onClick={() => setDirty(false)}>
            저장 (⌘S)
          </button>
        </div>

        <div style={{
          flex: 1,
          background: TOKENS.bg,
          minHeight: 0,
          display: 'flex',
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 12,
          overflow: 'auto',
        }}>
          <div style={{
            background: TOKENS.panel2,
            color: TOKENS.muted,
            padding: '12px 8px',
            textAlign: 'right',
            userSelect: 'none',
            lineHeight: '1.6em',
            fontSize: 11,
            minWidth: 42,
          }}>
            {lines.map((_, i) => <div key={i}>{i + 1}</div>)}
          </div>
          <pre style={{
            margin: 0, padding: '12px 12px',
            color: TOKENS.text,
            lineHeight: '1.6em',
            flex: 1,
            whiteSpace: 'pre',
          }}>
            {lines.map((line, i) => (
              <div key={i}>{colorizeYaml2(line)}</div>
            ))}
          </pre>
        </div>
      </div>

      {/* Side preview */}
      <div style={{
        background: TOKENS.panel,
        display: 'flex', flexDirection: 'column',
        minHeight: 0,
      }}>
        <div style={{
          padding: '10px 14px',
          borderBottom: `1px solid ${TOKENS.border}`,
          display: 'flex', alignItems: 'center', gap: 8,
        }}>
          <span style={{
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 10, letterSpacing: 1.4,
            color: TOKENS.dim, textTransform: 'uppercase',
          }}>매핑 미리보기</span>
          <span style={{ flex: 1 }} />
          <span style={{
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 10, color: TOKENS.text,
          }}>{Object.keys(D.gpMapping).length} 항목</span>
        </div>

        <div style={{ flex: 1, overflowY: 'auto', padding: 12, minHeight: 0 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {Object.entries(D.gpMapping).map(([reg, def]) => (
              <div key={reg} style={{
                background: TOKENS.bg,
                border: `1px solid ${TOKENS.border}`,
                borderLeft: `2px solid ${TOKENS.accent}`,
                padding: '10px 12px',
                display: 'grid',
                gridTemplateColumns: '1fr 20px 1fr',
                gap: 10,
                alignItems: 'center',
                fontFamily: 'JetBrains Mono, monospace',
                fontSize: 11,
              }}>
                <div style={{ minWidth: 0 }}>
                  <div style={{
                    color: TOKENS.cyan,
                    overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                  }}>{reg}</div>
                  <div style={{ color: TOKENS.muted, fontSize: 9, marginTop: 2 }}>
                    scale ×{def.scale}
                  </div>
                </div>
                <span style={{ color: TOKENS.dim, textAlign: 'center' }}>→</span>
                <div style={{ minWidth: 0 }}>
                  <div style={{
                    color: TOKENS.accent,
                    overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                  }}>{def.col}</div>
                  <div style={{ color: TOKENS.dim, fontSize: 9, marginTop: 2 }}>
                    {D.koLabels[def.col] || ''}
                    {D.units[def.col] && (
                      <span style={{ color: TOKENS.muted }}> · {D.units[def.col]}</span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div style={{
            marginTop: 16,
            padding: 12,
            background: TOKENS.bg,
            border: `1px solid ${TOKENS.border}`,
            borderLeft: `2px solid ${TOKENS.cyan}`,
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 10, color: TOKENS.dim,
            lineHeight: 1.6,
          }}>
            <div style={{ color: TOKENS.text, marginBottom: 4 }}>// HOT-RELOAD</div>
            이 파일을 저장하면 backend 서비스가 즉시 다시 읽어 ROBOT_FIELDS를 갱신함.
            새 컬럼이 추가되면 분석 차트에 자동 노출됨.
          </div>

          <div style={{
            marginTop: 10,
            padding: 12,
            background: TOKENS.bg,
            border: `1px solid ${TOKENS.border}`,
            borderLeft: `2px solid ${TOKENS.amber}`,
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 10, color: TOKENS.dim,
            lineHeight: 1.6,
          }}>
            <div style={{ color: TOKENS.text, marginBottom: 4 }}>// 주의</div>
            scale 값을 잘못 입력하면 차트 단위가 깨짐. 팬던트 PDF의 "값/단위" 컬럼과 대조 권장.
            <span style={{ color: TOKENS.amber }}> ×10</span> 표기는 scale 0.1 사용.
          </div>
        </div>
      </div>
    </div>
  );
}

const mapBtn = {
  background: TOKENS.panel2,
  border: `1px solid ${TOKENS.border}`,
  color: TOKENS.dim,
  fontFamily: 'JetBrains Mono, monospace',
  fontSize: 10, padding: '4px 10px',
  borderRadius: 2, cursor: 'pointer', letterSpacing: 0.5,
};

function colorizeYaml2(line) {
  if (/^\s*#/.test(line)) {
    return <span style={{ color: TOKENS.muted, fontStyle: 'italic' }}>{line || '\u00a0'}</span>;
  }
  const m = line.match(/^(\s*)([\w\d_]+)(\s*:)(\s*)(.*)$/);
  if (m) {
    const [, indent, key, colon, sp, val] = m;
    let valStyle = { color: TOKENS.text };
    if (/^["']/.test(val)) valStyle = { color: TOKENS.green };
    else if (/^-?\d/.test(val)) valStyle = { color: TOKENS.amber };
    else if (/^\[/.test(val)) valStyle = { color: TOKENS.cyan };
    return (
      <>
        <span>{indent}</span>
        <span style={{ color: TOKENS.accent }}>{key}</span>
        <span style={{ color: TOKENS.muted }}>{colon}</span>
        <span>{sp}</span>
        <span style={valStyle}>{val || '\u00a0'}</span>
      </>
    );
  }
  return <span>{line || '\u00a0'}</span>;
}

window.ScreenMapping = ScreenMapping;
