// Screen: 분석 워크스페이스 (RTDE post-recording)
// Wraps the Standard-variant analysis components into a screen-shaped layout
// (no AppChrome). Adds a top "loaded recording" bar with a quick-switch popover.

function ScreenAnalysis({ recording, changeRecording, library }) {
  const D = window.RTDE;
  const N = D.N;

  const [pinned, setPinned] = React.useState(['weldCurrent','Arc_percent','xOffset','zOffset']);
  const [brush, setBrush] = React.useState([Math.round(N * 0.55), Math.round(N * 0.82)]);
  const [hoverIdx, setHoverIdx] = React.useState(null);
  const [scatterX, setScatterX] = React.useState('weldCurrent');
  const [scatterY, setScatterY] = React.useState('Arc_percent');
  const [detailMode, setDetailMode] = React.useState('overlay');
  const [showSwitcher, setShowSwitcher] = React.useState(false);

  const colorFor = (name) => {
    const i = pinned.indexOf(name);
    return TOKENS.serieses[Math.max(0, i) % TOKENS.serieses.length];
  };
  const togglePin = (n) =>
    setPinned(p => p.includes(n) ? p.filter(x => x !== n) : [...p, n].slice(0, 6));

  const windowStats = React.useMemo(() => {
    const [a, b] = brush.slice().sort((x,y) => x-y);
    return pinned.map(c => {
      const arr = D.samples[c];
      let mn=Infinity, mx=-Infinity, s=0, n=0;
      for (let i=a; i<=b; i++) { const v=arr[i]; if(v<mn)mn=v; if(v>mx)mx=v; s+=v; n++; }
      const mean = n ? s/n : 0;
      let v2 = 0;
      for (let i=a; i<=b; i++) v2 += (arr[i]-mean)*(arr[i]-mean);
      const sd = Math.sqrt(v2 / Math.max(1, n));
      return { col: c, min: mn, max: mx, mean, std: sd };
    });
  }, [brush, pinned, D]);

  return (
    <div style={{
      flex: 1, display: 'flex', flexDirection: 'column',
      minHeight: 0, background: TOKENS.bg,
    }}>
      {/* Loaded recording bar */}
      <LoadedRecordingBar
        recording={recording}
        showSwitcher={showSwitcher}
        setShowSwitcher={setShowSwitcher}
        library={library}
        changeRecording={changeRecording}
      />

      <div style={{
        flex: 1, display: 'grid',
        gridTemplateColumns: '260px 1fr',
        gap: 1, background: TOKENS.border,
        minHeight: 0,
      }}>
        <AnalysisVarBrowser D={D} pinned={pinned} onToggle={togglePin} colorFor={colorFor} />

        <div style={{
          background: TOKENS.bg,
          display: 'grid',
          gridTemplateRows: 'auto 1fr auto auto',
          minHeight: 0, minWidth: 0,
        }}>
          <div style={{
            padding: '10px 14px',
            display: 'flex', alignItems: 'center', gap: 8,
            borderBottom: `1px solid ${TOKENS.border}`,
            flexWrap: 'wrap',
          }}>
            <span style={{
              fontFamily: 'JetBrains Mono, monospace',
              fontSize: 10, letterSpacing: 1.4,
              color: TOKENS.dim, textTransform: 'uppercase',
            }}>PINNED</span>
            {pinned.map(c => (
              <Chip key={c} color={colorFor(c)} active removable onRemove={() => togglePin(c)}>
                {c}
              </Chip>
            ))}
            <span style={{ flex: 1 }} />
            <AnalysisSegmented2 value={detailMode} onChange={setDetailMode}
              options={[['overlay','오버레이'],['stacked','상하분할']]} />
          </div>

          <div style={{
            padding: 12, minHeight: 0,
            background: TOKENS.panel,
            borderBottom: `1px solid ${TOKENS.border}`,
            display: 'flex', flexDirection: 'column',
          }}>
            <div style={{
              display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8,
            }}>
              <span style={{
                fontFamily: 'JetBrains Mono, monospace',
                fontSize: 10, color: TOKENS.dim, letterSpacing: 0.8,
              }}>
                FOCUS · {fmtT(D.t[Math.min(...brush)])} → {fmtT(D.t[Math.max(...brush)])}
                <span style={{ marginLeft: 8, color: TOKENS.accent }}>
                  Δ {fmtT(D.t[Math.max(...brush)] - D.t[Math.min(...brush)])}
                </span>
              </span>
              <span style={{ flex: 1 }} />
              <button onClick={() => setBrush([0, N - 1])} style={AnalysisBtnStyle}>전체 보기</button>
              <button onClick={() => setBrush([Math.round(N*0.55), Math.round(N*0.82)])}
                style={AnalysisBtnStyle}>이벤트 윈도우</button>
            </div>
            <div style={{ flex: 1, minHeight: 0 }}>
              {detailMode === 'overlay' ? (
                <AnalysisDetailOverlay D={D} pinned={pinned} colorFor={colorFor}
                  brush={brush} hoverIdx={hoverIdx} setHoverIdx={setHoverIdx} />
              ) : (
                <AnalysisDetailStacked D={D} pinned={pinned} colorFor={colorFor}
                  brush={brush} hoverIdx={hoverIdx} setHoverIdx={setHoverIdx} />
              )}
            </div>
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: 1,
            background: TOKENS.border,
            height: 260,
            minHeight: 0,
          }}>
            <div style={{ background: TOKENS.panel, padding: 12, display: 'flex', flexDirection: 'column' }}>
              <div style={{
                display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6,
              }}>
                <span style={{
                  fontFamily: 'JetBrains Mono, monospace',
                  fontSize: 10, letterSpacing: 1.4,
                  color: TOKENS.dim, textTransform: 'uppercase',
                }}>X · Y 상관관계</span>
                <span style={{ flex: 1 }} />
                <AnalysisVarPick D={D} value={scatterX} onChange={setScatterX} label="X" />
                <AnalysisVarPick D={D} value={scatterY} onChange={setScatterY} label="Y" />
              </div>
              <div style={{ flex: 1, minHeight: 0 }}>
                <AnalysisScatterPlot D={D} xCol={scatterX} yCol={scatterY}
                  brush={brush} hoverIdx={hoverIdx} setHoverIdx={setHoverIdx} />
              </div>
            </div>

            <div style={{ background: TOKENS.panel, padding: 12, display: 'flex', flexDirection: 'column' }}>
              <div style={{
                fontFamily: 'JetBrains Mono, monospace',
                fontSize: 10, letterSpacing: 1.4,
                color: TOKENS.dim, textTransform: 'uppercase',
                marginBottom: 8,
                display: 'flex', alignItems: 'center', gap: 8,
              }}>
                <span>윈도우 통계</span>
                <span style={{ flex: 1 }} />
                <span style={{ color: TOKENS.text }}>
                  {Math.abs(brush[1]-brush[0])+1} 샘플
                </span>
              </div>
              <AnalysisWindowStatsTable stats={windowStats} colorFor={colorFor} D={D} />
            </div>
          </div>

          <AnalysisBrushTimeline D={D} brush={brush} setBrush={setBrush}
            hoverIdx={hoverIdx} setHoverIdx={setHoverIdx}
            pinned={pinned} colorFor={colorFor} />
        </div>
      </div>
    </div>
  );
}

function LoadedRecordingBar({ recording, showSwitcher, setShowSwitcher, library, changeRecording }) {
  return (
    <div style={{
      padding: '10px 16px',
      background: TOKENS.panel,
      borderBottom: `1px solid ${TOKENS.border}`,
      display: 'flex', alignItems: 'center', gap: 16,
      position: 'relative',
      flex: '0 0 auto',
    }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10,
        padding: '4px 10px',
        background: TOKENS.bg, border: `1px solid ${TOKENS.border}`,
        borderLeft: `2px solid ${TOKENS.accent}`,
      }}>
        <span style={{
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 9, color: TOKENS.muted, letterSpacing: 1,
        }}>LOADED</span>
        <span style={{
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 12, color: TOKENS.text,
        }}>{recording.name}</span>
      </div>
      <div style={{
        display: 'flex', gap: 18,
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 10, color: TOKENS.dim,
      }}>
        <Meta label="블록" value={recording.block} />
        <Meta label="셀" value={recording.cell} color={TOKENS.cyan} />
        <Meta label="패스" value={recording.path} />
        <Meta label="작업자" value={recording.operator} />
        <Meta label="기간" value={fmtT(recording.duration)} />
        <Meta label="샘플" value={recording.samples.toLocaleString()} />
        <Meta label="알람" value={String(recording.alarms)} color={
          recording.alarms === 0 ? TOKENS.green
          : recording.alarms > 5 ? TOKENS.red : TOKENS.amber
        } />
      </div>
      <span style={{ flex: 1 }} />
      <button onClick={() => setShowSwitcher(s => !s)}
        style={{
          padding: '5px 12px',
          background: showSwitcher ? TOKENS.accent : 'transparent',
          color: showSwitcher ? '#0a0f1c' : TOKENS.dim,
          border: `1px solid ${showSwitcher ? TOKENS.accent : TOKENS.border}`,
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 10, letterSpacing: 0.6,
          cursor: 'pointer', borderRadius: 2,
        }}>
        다른 레코딩 ▾
      </button>
      <button style={{
        padding: '5px 12px',
        background: 'transparent', color: TOKENS.dim,
        border: `1px solid ${TOKENS.border}`,
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 10, letterSpacing: 0.6,
        cursor: 'pointer', borderRadius: 2,
      }}>내보내기</button>

      {showSwitcher && (
        <div style={{
          position: 'absolute',
          top: '100%', right: 16,
          marginTop: 4,
          width: 380, maxHeight: 360, overflowY: 'auto',
          background: TOKENS.panel,
          border: `1px solid ${TOKENS.borderHi}`,
          boxShadow: '0 8px 24px rgba(0,0,0,0.5)',
          zIndex: 20,
        }}>
          {library.map(r => (
            <button key={r.id}
              onClick={() => { changeRecording(r.id); setShowSwitcher(false); }}
              style={{
                width: '100%',
                padding: '10px 14px',
                background: r.id === recording.id ? TOKENS.bg : 'transparent',
                border: 'none',
                borderBottom: `1px solid ${TOKENS.border}`,
                borderLeft: r.id === recording.id ? `2px solid ${TOKENS.accent}` : `2px solid transparent`,
                color: TOKENS.text,
                textAlign: 'left',
                cursor: 'pointer',
                display: 'flex', flexDirection: 'column', gap: 3,
                fontFamily: 'JetBrains Mono, monospace',
              }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 6 }}>
                <span style={{ fontSize: 11, color: TOKENS.text }}>{r.name}</span>
                <span style={{
                  fontSize: 8, padding: '1px 4px',
                  background: r.source === 'db' ? TOKENS.violet + '33' : TOKENS.cyan + '33',
                  color: r.source === 'db' ? TOKENS.violet : TOKENS.cyan,
                  borderRadius: 1, letterSpacing: 0.5, fontWeight: 600,
                }}>{r.source.toUpperCase()}</span>
              </div>
              <div style={{ fontSize: 9, color: TOKENS.dim }}>
                {r.block} · {r.cell} · {r.path} · {r.operator} · {fmtT(r.duration)} · {r.alarms}A
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function Meta({ label, value, color }) {
  return (
    <span>
      <span style={{ color: TOKENS.muted }}>{label} </span>
      <span style={{ color: color || TOKENS.text }}>{value}</span>
    </span>
  );
}

window.ScreenAnalysis = ScreenAnalysis;
