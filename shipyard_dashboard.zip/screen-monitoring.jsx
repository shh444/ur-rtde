// Screen: 실시간 모니터링 (Modbus TCP)
// Hero KPIs at top → group tabs + filters → dense register grid.
// Subscribes to the modbus simulator so values animate live.

function ScreenMonitoring() {
  const M = window.MODBUS;
  const [state, setState] = React.useState(() => ({ ...M.state }));
  const [tick, setTick] = React.useState(0);
  React.useEffect(() => M.subscribe((s, t) => { setState({ ...s }); setTick(t); }), []);

  const [groupTab, setGroupTab] = React.useState('all');
  const [showReserved, setShowReserved] = React.useState(false);
  const [q, setQ] = React.useState('');
  const [selected, setSelected] = React.useState(null);

  const filtered = M.registers.filter(r => {
    if (!showReserved && r.status !== 'active') return false;
    if (groupTab !== 'all' && r.grp !== groupTab) return false;
    if (q) {
      const s = q.toLowerCase();
      if (!String(r.a).includes(s) &&
          !r.name.toLowerCase().includes(s) &&
          !r.en.toLowerCase().includes(s)) return false;
    }
    return true;
  });

  const grouped = {};
  filtered.forEach(r => {
    (grouped[r.grp] = grouped[r.grp] || []).push(r);
  });

  // Active count per group
  const countActive = (g) => M.registers.filter(r =>
    (g === 'all' || r.grp === g) && r.status === 'active').length;

  return (
    <div style={{
      flex: 1, display: 'flex', flexDirection: 'column',
      minHeight: 0, background: TOKENS.bg,
    }}>
      {/* HERO strip — most important live values */}
      <HeroStrip state={state} M={M} />

      {/* Filter bar */}
      <div style={{
        padding: '10px 16px',
        borderBottom: `1px solid ${TOKENS.border}`,
        display: 'flex', alignItems: 'center', gap: 8,
        background: TOKENS.panel2,
        flexWrap: 'wrap',
        flex: '0 0 auto',
      }}>
        <TabBtn active={groupTab === 'all'} onClick={() => setGroupTab('all')}
          label="전체" count={countActive('all')} color={TOKENS.dim} />
        {Object.values(M.groups).map(g => (
          <TabBtn key={g.id} active={groupTab === g.id} onClick={() => setGroupTab(g.id)}
            label={g.label} count={countActive(g.id)} color={g.color} sub={g.range} />
        ))}
        <span style={{ flex: 1 }} />
        <input value={q} onChange={(e) => setQ(e.target.value)}
          placeholder="주소·이름 검색 (예: 131, 전류)"
          style={{
            background: TOKENS.bg,
            border: `1px solid ${TOKENS.border}`,
            color: TOKENS.text,
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 11,
            padding: '5px 10px',
            borderRadius: 2,
            outline: 'none',
            width: 200,
          }} />
        <label style={{
          display: 'inline-flex', alignItems: 'center', gap: 6,
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 10, color: TOKENS.dim,
          cursor: 'pointer',
        }}>
          <input type="checkbox" checked={showReserved}
            onChange={(e) => setShowReserved(e.target.checked)}
            style={{ accentColor: TOKENS.accent }} />
          예약/미사용 표시
        </label>
      </div>

      {/* Main grid */}
      <div style={{
        flex: 1, minHeight: 0, overflowY: 'auto',
        padding: 16,
        display: 'grid',
        gridTemplateColumns: selected ? '1fr 340px' : '1fr',
        gap: 16,
      }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
          {Object.values(M.groups).map(g => {
            const items = grouped[g.id];
            if (!items || !items.length) return null;
            return (
              <section key={g.id}>
                <GroupHeader g={g} count={items.length} />
                <div style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))',
                  gap: 8,
                }}>
                  {items.map(r => (
                    <RegisterCard key={r.a} r={r}
                      value={state[r.a]}
                      tick={tick}
                      selected={selected === r.a}
                      onClick={() => setSelected(selected === r.a ? null : r.a)}
                    />
                  ))}
                </div>
              </section>
            );
          })}
        </div>

        {selected != null && (
          <RegisterDetail
            r={M.byAddr[selected]} state={state}
            onClose={() => setSelected(null)} />
        )}
      </div>

      <FooterBar state={state} tick={tick} />
    </div>
  );
}

function TabBtn({ active, onClick, label, count, color, sub }) {
  return (
    <button onClick={onClick}
      style={{
        padding: '5px 10px',
        background: active ? color + '22' : 'transparent',
        border: `1px solid ${active ? color : TOKENS.border}`,
        color: active ? color : TOKENS.dim,
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 10,
        letterSpacing: 0.5,
        cursor: 'pointer',
        borderRadius: 2,
        display: 'inline-flex', alignItems: 'center', gap: 6,
      }}>
      <span>{label}</span>
      {sub && <span style={{ color: TOKENS.muted, fontSize: 9 }}>{sub}</span>}
      <span style={{
        padding: '0 5px',
        background: active ? color : TOKENS.border,
        color: active ? '#0a0f1c' : TOKENS.dim,
        fontSize: 9, borderRadius: 1, fontWeight: 600,
      }}>{count}</span>
    </button>
  );
}

function GroupHeader({ g, count }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 10,
      padding: '0 0 8px',
      borderBottom: `1px solid ${TOKENS.border}`,
      marginBottom: 10,
    }}>
      <span style={{ width: 8, height: 8, background: g.color, borderRadius: 1 }} />
      <span style={{
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 11, color: TOKENS.text, fontWeight: 500, letterSpacing: 0.5,
      }}>{g.label}</span>
      <span style={{
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 9, color: TOKENS.muted, letterSpacing: 0.6,
      }}>{g.range}</span>
      <span style={{
        fontSize: 11, color: TOKENS.muted,
      }}>· {g.desc}</span>
      <span style={{ flex: 1 }} />
      <span style={{
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 10, color: TOKENS.dim,
      }}>{count}개</span>
    </div>
  );
}

function HeroStrip({ state, M }) {
  // Selected "hot" registers to show big.
  const items = [
    { a: 130, big: true, primary: true },
    { a: 131, big: true },
    { a: 132, big: true },
    { a: 133, big: false },
    { a: 134, big: false },
    { a: 135, big: false },
    { a: 136, big: false },
    { a: 162, big: false },
  ];
  const weldOn = state[130];
  const groupColors = M.groups;

  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: 'auto auto auto 1fr',
      gap: 1,
      background: TOKENS.border,
      padding: 1,
      flex: '0 0 auto',
    }}>
      {/* Big status panel: welding ON/OFF + cell + path */}
      <div style={{
        padding: '14px 18px',
        background: weldOn ? TOKENS.accent + '15' : TOKENS.panel,
        borderLeft: `3px solid ${weldOn ? TOKENS.accent : TOKENS.border}`,
        display: 'flex', flexDirection: 'column', gap: 4,
        minWidth: 200,
      }}>
        <div style={{
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 10, color: TOKENS.dim, letterSpacing: 1.2,
        }}>
          용접 상태 · ADDR 130
        </div>
        <div style={{
          display: 'flex', alignItems: 'baseline', gap: 10,
        }}>
          <span style={{
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 28, fontWeight: 600,
            color: weldOn ? TOKENS.accent : TOKENS.muted,
            letterSpacing: -0.5,
          }}>
            {weldOn ? '용접 중' : '무부하'}
          </span>
          {weldOn && <span style={{
            width: 10, height: 10, borderRadius: '50%',
            background: TOKENS.accent,
            boxShadow: `0 0 10px ${TOKENS.accent}`,
            animation: 'pulse 1.5s ease-in-out infinite',
          }} />}
        </div>
        <div style={{
          display: 'flex', gap: 12,
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 11, color: TOKENS.dim, marginTop: 2,
        }}>
          <span>셀 <span style={{ color: TOKENS.text }}>{state[135]}</span></span>
          <span>패스 <span style={{ color: TOKENS.text }}>{state[136]}/{state[139]}</span></span>
          <span>모드 <span style={{ color: TOKENS.text }}>{state[162] === 1 ? '수동' : '자동'}</span></span>
        </div>
      </div>

      {/* Live current */}
      <BigReadout addr={131} state={state} M={M} color={TOKENS.accent}
        sub={`목표 ${fmt(state[133], 0)} A`} />
      {/* Live voltage */}
      <BigReadout addr={132} state={state} M={M} color={TOKENS.cyan}
        sub={`목표 ${fmt(state[134], 1)} V`} />

      {/* Right: heartbeats + secondary */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(4, 1fr)',
        gap: 1,
        background: TOKENS.border,
      }}>
        <SmallReadout addr={128} state={state} M={M} label="ROBOT HB" />
        <SmallReadout addr={161} state={state} M={M} label="PEND HB" />
        <SmallReadout addr={214} state={state} M={M} label="와이어 송급" big={`${fmt(state[214], 1)}`} unit="m/min" />
        <SmallReadout addr={142} state={state} M={M} label="ROBOT ERR"
          big={state[142] === 0 ? 'OK' : `E${state[142]}`}
          color={state[142] === 0 ? TOKENS.green : TOKENS.red} />
      </div>
    </div>
  );
}

function BigReadout({ addr, state, M, color, sub }) {
  const r = M.byAddr[addr];
  const hist = M.getHist(addr);
  return (
    <div style={{
      padding: '14px 18px',
      background: TOKENS.panel,
      display: 'flex', flexDirection: 'column', gap: 4,
      minWidth: 200,
    }}>
      <div style={{
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 10, color: TOKENS.dim, letterSpacing: 1.2,
      }}>
        {r.name} · ADDR {addr}
      </div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
        <span style={{
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 32, fontWeight: 500, color,
          letterSpacing: -0.5,
        }}>{fmt(state[addr], r.unit === 'V' ? 1 : 0)}</span>
        <span style={{
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 12, color: TOKENS.dim,
        }}>{r.unit}</span>
      </div>
      <Sparkline values={hist} w={180} h={26} color={color} fill />
      <div style={{
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 10, color: TOKENS.muted,
      }}>{sub}</div>
    </div>
  );
}

function SmallReadout({ addr, state, M, label, big, unit, color }) {
  const r = M.byAddr[addr];
  return (
    <div style={{
      padding: '8px 10px',
      background: TOKENS.panel,
      display: 'flex', flexDirection: 'column', gap: 2,
    }}>
      <div style={{
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 9, color: TOKENS.muted, letterSpacing: 0.8,
      }}>{label} · {addr}</div>
      <div style={{
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 16, fontWeight: 500,
        color: color || TOKENS.text,
      }}>
        {big != null ? big : fmt(state[addr], 0)}
        {unit && <span style={{ fontSize: 9, color: TOKENS.dim, marginLeft: 4 }}>{unit}</span>}
      </div>
    </div>
  );
}

function RegisterCard({ r, value, tick, selected, onClick }) {
  // Detect value-changed within last few ticks to flash
  const prev = React.useRef(value);
  const [flash, setFlash] = React.useState(false);
  React.useEffect(() => {
    if (prev.current !== value) {
      setFlash(true);
      const id = setTimeout(() => setFlash(false), 250);
      prev.current = value;
      return () => clearTimeout(id);
    }
  }, [value]);

  const M = window.MODBUS;
  const grpColor = M.groups[r.grp].color;
  const isActive = r.status === 'active';
  const isNumeric = typeof value === 'number' && r.kind !== 'bool';

  return (
    <div onClick={onClick}
      style={{
        background: TOKENS.panel,
        borderTop: `1px solid ${selected ? grpColor : flash ? TOKENS.accent : TOKENS.border}`,
        borderRight: `1px solid ${selected ? grpColor : flash ? TOKENS.accent : TOKENS.border}`,
        borderBottom: `1px solid ${selected ? grpColor : flash ? TOKENS.accent : TOKENS.border}`,
        borderLeft: `2px solid ${isActive ? grpColor : TOKENS.border}`,
        padding: '8px 10px',
        cursor: 'pointer',
        display: 'flex', flexDirection: 'column', gap: 4,
        opacity: isActive ? 1 : 0.45,
        transition: 'border-color 0.2s',
        minWidth: 0,
      }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 6,
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 9, color: TOKENS.muted, letterSpacing: 0.6,
      }}>
        <span style={{
          background: TOKENS.bg,
          padding: '1px 5px', color: grpColor, fontWeight: 600,
          borderRadius: 1,
        }}>{r.a}</span>
        <span style={{
          color: TOKENS.dim,
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
          flex: 1,
        }}>{r.en}</span>
        {r.kind === 'bitfield' && <span style={{ color: TOKENS.violet }}>·BF</span>}
        {r.kind === 'enum' && <span style={{ color: TOKENS.violet }}>·EN</span>}
      </div>
      <div style={{
        fontSize: 11, color: TOKENS.text,
        whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
      }}>{r.name}</div>
      <div style={{
        display: 'flex', alignItems: 'baseline', gap: 4,
      }}>
        <span style={{
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 17, fontWeight: 500,
          color: !isActive ? TOKENS.muted
                : flash ? TOKENS.accent
                : isNumeric ? TOKENS.text
                : r.kind === 'bool' ? (value ? TOKENS.green : TOKENS.muted)
                : TOKENS.text,
          transition: 'color 0.25s',
        }}>
          {!isActive ? '—'
           : r.kind === 'bool' ? (value ? 'ON' : 'OFF')
           : r.kind === 'enum' ? value
           : r.kind === 'bitfield' ? '0b' + (value || 0).toString(2).padStart(8, '0')
           : r.kind === 'string' ? value
           : fmt(value, r.unit === 'V' || r.unit === 'A' ? 1 : 0)}
        </span>
        {r.unit && <span style={{
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 9, color: TOKENS.muted,
        }}>{r.unit}</span>}
      </div>
    </div>
  );
}

function RegisterDetail({ r, state, onClose }) {
  const M = window.MODBUS;
  const hist = M.getHist(r.a);
  const value = state[r.a];
  const grpColor = M.groups[r.grp].color;

  return (
    <aside style={{
      background: TOKENS.panel,
      borderTop: `1px solid ${TOKENS.border}`,
      borderRight: `1px solid ${TOKENS.border}`,
      borderBottom: `1px solid ${TOKENS.border}`,
      borderLeft: `2px solid ${grpColor}`,
      padding: 16,
      display: 'flex', flexDirection: 'column', gap: 14,
      position: 'sticky', top: 0,
      alignSelf: 'flex-start',
      maxHeight: 'calc(100vh - 240px)',
      overflowY: 'auto',
    }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8,
        borderBottom: `1px solid ${TOKENS.border}`,
        paddingBottom: 12,
      }}>
        <span style={{
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 11, color: grpColor, fontWeight: 600,
          padding: '2px 6px', background: TOKENS.bg, borderRadius: 1,
        }}>ADDR {r.a}</span>
        <span style={{ flex: 1 }} />
        <button onClick={onClose}
          style={{
            background: 'transparent', border: 'none',
            color: TOKENS.dim, cursor: 'pointer', fontSize: 16,
          }}>×</button>
      </div>
      <div>
        <div style={{ fontSize: 15, color: TOKENS.text, marginBottom: 2 }}>
          {r.name}
        </div>
        <div style={{
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 10, color: TOKENS.muted, letterSpacing: 0.4,
        }}>
          {r.en} · {M.groups[r.grp].label}
        </div>
      </div>
      <div style={{
        background: TOKENS.bg,
        padding: '12px 14px',
        border: `1px solid ${TOKENS.border}`,
        display: 'flex', flexDirection: 'column', gap: 6,
      }}>
        <div style={{
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 9, color: TOKENS.muted, letterSpacing: 1,
        }}>현재 값</div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
          <span style={{
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 26, fontWeight: 500, color: grpColor,
          }}>
            {r.status !== 'active' ? '—'
             : r.kind === 'bool' ? (value ? 'ON' : 'OFF')
             : r.kind === 'enum' ? value
             : r.kind === 'bitfield' ? '0b' + (value||0).toString(2).padStart(8,'0')
             : r.kind === 'string' ? value
             : fmt(value, 2)}
          </span>
          {r.unit && <span style={{
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 11, color: TOKENS.dim,
          }}>{r.unit}</span>}
        </div>
        <div style={{ marginTop: 4 }}>
          <Sparkline values={hist} w={290} h={56} color={grpColor} fill />
        </div>
        <div style={{
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 9, color: TOKENS.muted,
          display: 'flex', justifyContent: 'space-between',
        }}>
          <span>{histAgg(hist, 'min', 2)}</span>
          <span>{histAgg(hist, 'mean', 2)}</span>
          <span>{histAgg(hist, 'max', 2)}</span>
        </div>
      </div>

      <DetailRow label="범위" value={r.range ? `${r.range[0]} … ${r.range[1]}` : '—'} />
      <DetailRow label="단위" value={r.unit || '—'} />
      <DetailRow label="유형" value={r.kind} />
      <DetailRow label="상태"
        value={r.status === 'active' ? '활성' : r.status === 'reserved' ? '예약' : '미사용'} />
      {r.enums && <DetailRow label="값" value={r.enums.join(' / ')} />}

      {r.desc && (
        <div style={{
          padding: 10, background: TOKENS.bg,
          border: `1px solid ${TOKENS.border}`,
          fontSize: 11, color: TOKENS.dim, lineHeight: 1.5,
        }}>
          {r.desc}
        </div>
      )}
    </aside>
  );
}

function DetailRow({ label, value }) {
  return (
    <div style={{
      display: 'flex', justifyContent: 'space-between',
      fontFamily: 'JetBrains Mono, monospace',
      fontSize: 11, padding: '4px 0',
      borderBottom: `1px solid ${TOKENS.border}33`,
    }}>
      <span style={{ color: TOKENS.muted }}>{label}</span>
      <span style={{ color: TOKENS.text }}>{value}</span>
    </div>
  );
}

function histAgg(arr, kind, d = 1) {
  if (!arr || !arr.length) return '—';
  if (kind === 'min') return 'min ' + fmt(Math.min(...arr), d);
  if (kind === 'max') return 'max ' + fmt(Math.max(...arr), d);
  const s = arr.reduce((a, b) => a + b, 0);
  return 'avg ' + fmt(s / arr.length, d);
}

function FooterBar({ state, tick }) {
  return (
    <div style={{
      height: 26, flex: '0 0 auto',
      borderTop: `1px solid ${TOKENS.border}`,
      background: TOKENS.panel2,
      display: 'flex', alignItems: 'center',
      padding: '0 12px', gap: 16,
      fontFamily: 'JetBrains Mono, monospace',
      fontSize: 10, color: TOKENS.dim, letterSpacing: 0.6,
    }}>
      <span>● MODBUS LIVE · {tick} ticks</span>
      <span>·</span>
      <span>POLL 250ms</span>
      <span>·</span>
      <span>HEARTBEAT 128 / 161 OK</span>
      <span style={{ flex: 1 }} />
      <span>WCR / STICK: 0b{(state[211] || 0).toString(2).padStart(8, '0')}</span>
      <span>·</span>
      <span>ERR: {state[142] || 0}</span>
    </div>
  );
}

window.ScreenMonitoring = ScreenMonitoring;
